--Ｍ・ＨＥＲＯ ダーク・ロウ
function c100000519.initial_effect(c)
end
